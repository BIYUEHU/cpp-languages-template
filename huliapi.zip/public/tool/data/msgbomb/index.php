<html lang="zh-CN">

<head>

    <meta charset="utf-8">
    <title>HULI短信洪渣鸡</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="format-detection" content="telephone=no">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />
    <link rel="stylesheet" href="//cdn.staticfile.org/bootstrap/5.3.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="//css.letvcdn.com/lc04_yinyue/201612/19/20/00/bootstrap.min.css">
    <style>
        body {
            background: #ecedf0 url("https://pic.imgdb.cn/item/63be9929be43e0d30e01626a.jpg") fixed;
            background-repeat: no-repeat;
            background-size: 100% 100%
        }
    </style>
    <script src="//cdn.staticfile.org/jquery/3.7.0/jquery.min.js"></script>
    <script src="//cdn.staticfile.org/bootstrap/5.3.0/js/bootstrap.min.js"></script>
</head>

<body>
    <div class="container col-xs-12 col-sm-10 col-lg-8 center-block panel panel-primary" style="padding-top:20px;float: none;">
        <div class="panel-heading" style="background: linear-gradient(to right,#8ae68a,#5ccdde,#b221ff);">
            <span style="color:black;text-align: center;"><b>HULI短信洪渣鸡</b></span>
        </div>

        <div class="panel-body">
            <div class="alert alert-success" style="text-align: center;">
                <a href="/">
                    <img class="img-circle m-b-xs" style="border: 2px solid #1281FF; margin-left:3px; margin-right:3px;" src="/favicon.ico" ; width="60px" height="60px" alt="HULIAPI短信洪渣鸡">
                </a>
            </div>

            <form>
                <marquee>
                    <b><span style="color:#ff0000">2021-05-29 HULI短信洪渣鸡开始运行！</span></b>
                </marquee>
                <div class="input-group">
                    <span class="input-group-addon">手机号码:</span>
                    <input autocomplete="off" size="30" name="phone" class="form-control" required="required" id="phone" />
                </div>
                <button class="btn btn-primary btn-block bk-margin-top-10" type="submit">点击开始</button>
            </form>

            <?php include('api.php'); ?>

            <br>
            <p> 公告:输入手机号即可！接口后续会增加！请勿泛滥！</p>
            <div class="col-xs-12 col-sm-10 col-md-8 col-lg-6 center-block" style="float: none;">
                <div class="panel-infol">
                    <p style="text-align:center"><br>ByBiyuehu</p>
                </div>
            </div>
        </div>
    </div>
</body>

</html>