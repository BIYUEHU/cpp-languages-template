<?php
return [
    'host' => 'api.imlolicon.tk',
    'port' => 3306,
    'dbName' => 'ialcore',
    'userName' => 'ialcore',
    'passWord' => '05170517'
];
