<?php
return [
	"engine_version" => "3.0.0",
	"header" => [
		"type" => "theme",
		"uuid" => "1889db49-a42c-2bcf-2a14-da1e0a7c0574",
		// "icon" => "",
		"name" => "纯白",
		"descr" => "纯白系主题",
		"version" => "0.2.1"
	],
	"info" => [
		"author" => "Huli",
		"license" => "",
		"url" => ""
	]
];
