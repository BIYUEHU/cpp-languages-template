<?php
$title = '404';
include(__DIR__ . '/header.php');
?>

<!--主干部分-->
<section class="content content-boxed">
    <div style="text-align:center;font-size:16px;color:var(--set-main-color);">
        <strong>
            <h1>(≧﹏ ≦)404</h1>
        </strong><br>
        <h1>Sorry,cannot find the page need you</h1>
    </div>
    <div><br></div>
    <div><br></div>
</section>

<?php
include(__DIR__ . '/footer.php');
?>

</body>

</html>