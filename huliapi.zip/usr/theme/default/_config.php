<?php
return [
    /* 主题配置 */
    // 主题配色
    'mainColor' => 'pink',
    // 强调配色
    'accentColor' => 'green',
    // 顶部项目
    'headUrl' => '登录,/admin/|友链,/friends|',
    // 顶部提示语
    'tips' => '',
    // 弹窗公告
    'openEjct' => '',
    // 滚动公告
    'openRoll' => '',
    // 广告图片
    'advert' => '',
    // 底部信息
    'bottom1' => '',
    'bottom2' => '',

    // 自定义头部代码
    'codeHead' => '',

    // 自定义脚部代码
    'codeFoot' => '',

    //友链
    'friends' => ''
];
