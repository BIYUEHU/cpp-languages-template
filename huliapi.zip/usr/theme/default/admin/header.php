<?php
/*
 * @Author: Biyuehu biyuehuya@gmail.com
 * @Blog: http://imlolicon.tk
 * @Date: 2023-01-17 13:36:45
 */
require_once(__DIR__ . '../../function.php');

$rootTitle = '后台';
$content = spawnHtmlHeaderOption(APP_USER_PATH . '/loginout', 'fa-sign-out', '退出');
include(__DIR__ . '../../user/header.php');
?>
