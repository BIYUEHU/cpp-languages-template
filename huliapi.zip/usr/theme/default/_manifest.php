<?php
return [
	"engine_version" => "3.0.0",
	"header" => [
		"type" => "theme",
		"uuid" => "1889db49-a42c-2bcf-2a14-da1e0a7c0574",
		"icon" => "icon.png",
		"name" => "默认主题",
		"descr" => "a default theme to huliapi",
		"version" => "1.0.0"
	],
	"info" => [
		"author" => "Biyuehu",
		"license" => "",
		"url" => "http://imlolicon.tk"
	]
];
