<?php
return [
    'path' => 'https://api.imlolicon.tk/index.php/assets',
    'repo' => 'https://github.com/biyuehu/hulicore'
];