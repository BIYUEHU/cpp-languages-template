<?php
return [
    /* 数据库前缀 */
    'prefix' => 'huliapi_',
    /* 数据库地址 */
    'host' => 'api.imlolicon.tk',
    /* 数据库端口 */
    'port' => 3306,
    /* 数据库名字 */
    'dbName' => 'apidatabase',
    /* 用户名 */
    'userName' => 'apidatabase',
    /* 密码 */
    'passWord' => '05170517'
];
