<?php
/* 文章页路由 */
return [
    'apishop' => 'apiShop.html',
    'website' => 'website.html'
];
