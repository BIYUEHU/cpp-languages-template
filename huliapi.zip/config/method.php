<?php
/* 允许的请求方法(Request Method) */
return [
    'GET',
    'POST',
    'FILE',
    'HEAD'
];