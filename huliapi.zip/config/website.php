<?php
return [
    'api' => [
        'bing' => '您的apikey'
        /* ... */
    ]
];