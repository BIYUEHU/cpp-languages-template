<?php
return [
    /* 调试模式 */
    'debug' => true,
    /* 输出方式 */
    'debug_mode' => 'print_r'
];
